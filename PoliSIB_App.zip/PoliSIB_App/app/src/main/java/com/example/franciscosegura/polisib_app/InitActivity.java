package com.example.franciscosegura.polisib_app;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class InitActivity extends AppCompatActivity {
    MODEL_PoliSIB polisib;

    EditText eTextUser;
    Spinner spinRol;
    EditText eTextContraseña;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        polisib = new MODEL_PoliSIB();

        setContentView(R.layout.activity_init);
        eTextUser = (EditText)findViewById(R.id.editTextUser_I);
        spinRol = (Spinner)findViewById(R.id.roles);
        eTextContraseña = (EditText)findViewById(R.id.editTextPass_I);

    }

    /*
    darInfo: FUNCION QUE MUESTRA INFORMACION DE NOSOTROS AL USUARIO
     */
    public void darInfo(View view){
        Toast toast = Toast.makeText(this, "Sitio en proceso...", Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
        toast.show();
    }
    /*
    loggin: Funcion que verifica los datos del loogin, y va a la pantalla del usuario
     */
    public void loggin(View view){
        /*
        Verificar datos de loggin
         */
        String nombre = eTextUser.getText().toString();
        String rol = spinRol.getSelectedItem().toString();
        String pass = eTextContraseña.getText().toString();
        if(polisib.iniciarSesion(nombre, rol, pass)){
            Intent m = new Intent(this, UsuarioActivity.class);
            m.putExtra("nombre", nombre);
            startActivity(m);

        }else{
            Toast toast = Toast.makeText(this, "Datos INCORRECTOS!!!", Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
            toast.show();
        }
    }
    /*
    registrar: funcion para registrar un nuevo usuario en el sistema
     */
    public void registrar(View view){
        Intent m = new Intent(this, RegistroActivity.class);
        m.putExtra("polisib", polisib);
        startActivity(m);
    }
}
