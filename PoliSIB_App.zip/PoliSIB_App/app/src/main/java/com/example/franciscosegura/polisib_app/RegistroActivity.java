package com.example.franciscosegura.polisib_app;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class RegistroActivity extends AppCompatActivity {

    MODEL_PoliSIB poliSIB;
    EditText eTextUser;
    TextView textRol;
    EditText ePass;
    EditText ePass2;

    Toast toast;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);
        poliSIB = (MODEL_PoliSIB) getIntent().getExtras().getSerializable("polisib");
        eTextUser = (EditText)findViewById(R.id.editUserReg);
        textRol = (TextView)findViewById(R.id.textRol2);
        ePass = (EditText)findViewById(R.id.editPassReg);
        ePass2 = (EditText)findViewById(R.id.editCPassReg);
    }

    /*
   bAceptar: funcion que registra un usuario en el sistema
    */
    public void bAceptar(View view){
        String nombre = eTextUser.getText().toString();
        String rol = textRol.getText().toString();
        String con = ePass.getText().toString();
        String ccon = ePass2.getText().toString();
        if(poliSIB.noEsta(nombre)){
            if(poliSIB.añadirUsuario(nombre, rol, con, ccon)){
                toast = Toast.makeText(this, "Registro exitoso!", Toast.LENGTH_SHORT);
                toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
                toast.show();
                Intent m = new Intent(this, InitActivity.class);
                startActivity(m);
            }else{
                toast = Toast.makeText(this, "Hubo un error, intentelo nuevamente!", Toast.LENGTH_SHORT);
                toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
                toast.show();
            }

        }else{
            toast = Toast.makeText(this, "El usuario ya existe!!!", Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
            toast.show();
        }

    }
}
