package com.example.franciscosegura.polisib_app;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Created by Francisco Segura on 09/05/2016.
 */
@SuppressWarnings("serial")
public class MODEL_PoliSIB implements Serializable{

    private ArrayList<MODEL_Usuario> listaUsuarios;
    private ArrayList<MODEL_Bicicleta> listaBicicletas;
    private ArrayList<MODEL_Reserva> listaReserva;

    public MODEL_PoliSIB(){
        this.listaUsuarios = new ArrayList<MODEL_Usuario>();
        this.listaBicicletas = new ArrayList<MODEL_Bicicleta>();
        this.listaReserva = new ArrayList<MODEL_Reserva>();
    }

    public boolean añadirUsuario(String n, String r, String c, String cc){
        boolean estado = false;
        if(noEsta(n) && c.equals(cc)){
            MODEL_Usuario u1 = new MODEL_Usuario(n, r, c);
            estado = true;
        }
        return estado;
    }
    public boolean iniciarSesion(String n, String r, String p){
        for (int i = 0; i < listaUsuarios.size(); i++){
            if(listaUsuarios.get(i).getNombre().equals(n)){
                if(listaUsuarios.get(i).getContraseña().equals(p) && listaUsuarios.get(i).getRol().equals(r)){
                    return true;
                }
            }
        }
        return false;
    }
    public boolean noEsta(String n){
        for (int i = 0; i < listaUsuarios.size(); i++){
            if(listaUsuarios.get(i).getNombre().equals(n)){
                return false;
            }
        }
        return true;
    }
    public ArrayList<MODEL_Usuario> getListaUsuarios() {
        return listaUsuarios;
    }

    public void setListaUsuarios(ArrayList<MODEL_Usuario> listaUsuarios) {
        this.listaUsuarios = listaUsuarios;
    }

    public ArrayList<MODEL_Bicicleta> getListaBicicletas() {
        return listaBicicletas;
    }

    public void setListaBicicletas(ArrayList<MODEL_Bicicleta> listaBicicletas) {
        this.listaBicicletas = listaBicicletas;
    }

    public ArrayList<MODEL_Reserva> getListaReserva() {
        return listaReserva;
    }

    public void setListaReserva(ArrayList<MODEL_Reserva> listaReserva) {
        this.listaReserva = listaReserva;
    }
}
