package com.example.franciscosegura.polisib_app;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class UsuarioActivity extends AppCompatActivity {

    TextView textInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_usuario);
        textInfo = (TextView)findViewById(R.id.textInfo);
        textInfo.setText(getIntent().getExtras().getString("nombre"));
    }

    public void bEmergencia(View view){
        Toast toast = Toast.makeText(this, "Funcionalidad en proceso...", Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
        toast.show();
    }
    public void bReservar(View view){
        Toast toast = Toast.makeText(this, "Funcionalidad en proceso...", Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
        toast.show();
    }
    public void bConsultar(View view){
        Toast toast = Toast.makeText(this, "Funcionalidad en proceso...", Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
        toast.show();
    }
    public void bMapa(View view){
        Toast toast = Toast.makeText(this, "Funcionalidad en proceso...", Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
        toast.show();
    }
    public void bNotificaciones(View view){
        Toast toast = Toast.makeText(this, "Funcionalidad en proceso...", Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
        toast.show();
    }
    public void bCerrarSesion(View view){
        Toast toast = Toast.makeText(this, "Hasta pronto...", Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
        toast.show();
        Intent m = new Intent(this, InitActivity.class);
        startActivity(m);
    }
}
