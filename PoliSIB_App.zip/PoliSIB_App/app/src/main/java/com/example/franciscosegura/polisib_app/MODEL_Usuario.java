package com.example.franciscosegura.polisib_app;

import android.media.Image;

/**
 * Created by Francisco Segura on 09/05/2016.
 */
public class MODEL_Usuario {

    private String nombre;
    private String rol;
    private String contraseña;

    Image imagenPerfil;

    public MODEL_Usuario(String n, String r, String c){
        this.nombre = n;
        this.rol = r;
        this.contraseña = c;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }
}
