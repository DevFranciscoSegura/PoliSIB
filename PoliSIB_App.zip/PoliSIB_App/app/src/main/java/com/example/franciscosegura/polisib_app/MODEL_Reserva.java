package com.example.franciscosegura.polisib_app;

import java.util.Date;

/**
 * Created by Francisco Segura on 09/05/2016.
 */
public class MODEL_Reserva {

    Date fechaIncial;

    public MODEL_Reserva(){

    }

}
